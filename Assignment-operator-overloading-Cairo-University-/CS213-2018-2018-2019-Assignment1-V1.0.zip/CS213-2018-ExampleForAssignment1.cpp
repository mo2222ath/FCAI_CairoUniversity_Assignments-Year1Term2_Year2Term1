// Program: Cs213-2018-ExampleForAssignment1.cpp
// Purpose: Demonstrate use of sturctures and overloading
// Author:  Mohammad El-Ramly
// Date:    10 August 2018
// Version: 1.0

#include <iostream>
#include <cassert>
#include <iomanip>

using namespace std;

struct fraction
{
  int nom, dom;
};

fraction createFraction (int nom, int dom);
ostream& operator<< (ostream& out, fraction frac);
fraction operator+  (fraction frac1, fraction frac2);
fraction operator+= (fraction& frac1, fraction frac2);
fraction operator/  (fraction frac1, fraction frac2);

//__________________________________________

int main()
{
  fraction f1 = createFraction (1, 2);
  fraction f2 = createFraction (1, 3);

  cout << "Fraction 1   " << f1 << endl;
  cout << "Fraction 2   " << f2 << endl;

  cout << "Fraction 1 /  Fraction 2   " << f1/f2 << endl;
  cout << "Fraction 1 +  Fraction 2   " << f1+f2 << endl;
  cout << "Fraction 1 += Fraction 2   " << (f1+=f2) << endl;

  cout << "Now fraction 1   " << f1 << endl;
  cout << "Now fraction 2   " << f2 << endl;

  return 0;
}

//__________________________________________
// This function takes two int and returns a fraction
// of (first int) / (second int)
fraction createFraction (int nom, int dom) {
  fraction frac;
  frac.nom = nom;
  frac.dom = dom;
  return frac;
}

//__________________________________________
// This operator << takes two parameters: cout and fraction
// It allows me to write cout << fraction;
// It returns cout again so I can write cout << fraction << x;
ostream& operator<< (ostream& out, fraction frac) {
  out << frac.nom << "/" << frac.dom;
  return out;
}

//__________________________________________
// Returns the division of two given fraction
// Checks that dom will not be zero
fraction operator/ (fraction frac1, fraction frac2) {
  assert((frac1.dom != 0) && (frac2.nom != 0));

  fraction frac;
  frac.nom = frac1.nom * frac2.dom;
  frac.dom = frac1.dom * frac2.nom;
  return frac;
}

//__________________________________________
// Returns the sum of two given fraction
// Checks that dom will not be zero
fraction operator+ (fraction frac1, fraction frac2) {
  assert((frac1.dom != 0) && (frac2.dom != 0));

  fraction frac;
  frac.nom = frac1.nom * frac2.dom + frac1.dom * frac2.nom;
  frac.dom = frac1.dom * frac2.dom;
  return frac;
}

//__________________________________________
// If you write f1 += f2, now f1 will be sum of f1 + f2
// And returns the sum of two given fraction
// Checks that dom will not be zero
fraction operator+= (fraction& frac1, fraction frac2) {
  assert((frac1.dom != 0) && (frac2.dom != 0));

  fraction frac;
  frac.nom = frac1.nom * frac2.dom + frac1.dom * frac2.nom;
  frac.dom = frac1.dom * frac2.dom;
  frac1.nom = frac.nom;
  frac1.dom = frac.dom;
  return frac;
}
